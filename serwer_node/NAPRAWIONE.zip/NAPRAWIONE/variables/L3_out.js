//wyjscia swiatla 3 pietro

module.exports = {
  wyj_l3_1_1: "Q130.4",
  wyj_l3_1_2: "Q130.5",
  wyj_l3_2_1: "Q130.6",
  wyj_l3_2_2: "Q130.7",
  wyj_l3_3_1: "Q131.0",
  wyj_l3_3_2: "Q131.1",
  wyj_l3_4_1: "Q131.2",
  wyj_l3_4_2: "Q131.3",
  wyj_l3_5_1: "Q131.4",
  wyj_l3_5_2: "Q131.5",
  wyj_l3_6_1: "Q131.6",
  wyj_l3_6_2: "Q131.7",
  wyj_l3_7_1: "Q132.0",
  wyj_l3_7_2: "Q132.1",
};
