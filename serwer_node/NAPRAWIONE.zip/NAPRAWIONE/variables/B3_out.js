//wyjscia rolet 3 pietro
module.export = {
  wyj_b3_r4_1: "Q133.0",
  wyj_b3_r4_2: "Q133.1",
  wyj_b3_r5_1: "Q133.2",
  wyj_b3_r5_2: "Q133.3",
  wyj_b3_r6_1: "Q133.4",
  wyj_b3_r6_2: "Q133.5",
  wyj_b3_r7_1: "Q133.6",
  wyj_b3_r7_2: "Q133.7",
};
