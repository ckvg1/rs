//wejscia rolet 3 pietro
module.export = {
  wej_b3_r4_1: "DB13,X2.5",
  wej_b3_r4_2: "DB13,X2.6",
  wej_b3_r5_1: "DB13,X2.7",
  wej_b3_r5_2: "DB13,X3.0",
  wej_b3_r6_1: "DB13,X3.1",
  wej_b3_r6_2: "DB13,X3.2",
  wej_b3_r7_1: "DB13,X3.3",
  wej_b3_r7_2: "DB13,X3.4",
};
