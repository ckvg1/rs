//plik z zmiennymi z trzeciego pietra

module.exports = {
  t3_1: "DB9,REAL80",
  t3_2: "DB9,REAL84",
  t3_3: "DB9,REAL88",
  t3_4: "DB9,REAL92",
  t3_5: "DB9,REAL96",
  t3_6: "DB9,REAL100",
  t3_7: "DB9,REAL104",
};
