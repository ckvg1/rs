//plik z zmiennymi z trzeciego pietra

module.exports = {
  wej_l3_1_1: "DB13,X0.4",
  wej_l3_1_2: "DB13,X0.5",
  wej_l3_2_1: "DB13,X0.6",
  wej_l3_2_2: "DB13,X0.7",
  wej_l3_3_1: "DB13,X1.0",
  wej_l3_3_2: "DB13,X1.1",
  wej_l3_4_1: "DB13,X1.2",
  wej_l3_4_2: "DB13,X1.3",
  wej_l3_5_1: "DB13,X1.4",
  wej_l3_5_2: "DB13,X1.5",
  wej_l3_6_1: "DB13,X1.6",
  wej_l3_6_2: "DB13,X1.7",
  wej_l3_7_1: "DB13,X2.0",
  wej_l3_7_2: "DB13,X2.1",

  

  wej_b3_r4_1: "DB13,X2.5",
  wej_b3_r4_2: "DB13,X2.6",
  wej_b3_r5_1: "DB13,X2.7",
  wej_b3_r5_2: "DB13,X3.0",
  wej_b3_r6_1: "DB13,X3.1",
  wej_b3_r6_2: "DB13,X3.2",
  wej_b3_r7_1: "DB13,X3.3",
  wej_b3_r7_2: "DB13,X3.4",

 
};

